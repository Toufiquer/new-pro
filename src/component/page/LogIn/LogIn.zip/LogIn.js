import React, { useState } from "react";
import img from "../../../assets/images/appointment.png";
import auth from "../../Share/firebase.init";
import { useSignInWithGoogle } from "react-firebase-hooks/auth";
import { useForm } from "react-hook-form";
const LogIn = () => {
    const [signInWithGoogle, user, loading, error] = useSignInWithGoogle(auth);
    const {
        register,
        handleSubmit,
        watch,
        formState: { errors },
    } = useForm();
    user && console.log(user);
    const [password, SetPassword] = useState("");
    const [conPassword, SetConPassword] = useState("");
    const [email, SetEmail] = useState("");
    const [err, SetErr] = useState(null);
    // const handleSubmit = e => {
    //     e.preventDefault();
    //     console.log(e);
    // };
    const [logIn, SetLogIn] = useState(true);
    const handlePassword = () => {
        if (password !== conPassword) {
            SetErr("Password do not match");
        } else {
            SetErr(null);
        }
    };
    return (
        <div className="container mx-auto">
            <div
                className="my-6 min-h-full py-6"
                style={{ background: `url(${img})` }}
            >
                <div className="text-center py-6">
                    <div className="text-2xl font-bold">
                        {logIn ? "Sign Up" : "Login"}
                    </div>
                </div>
                <form
                    onSubmit={handleSubmit}
                    className="flex flex-col w-full lg:w-2/4 mx-auto gap-4"
                >
                    <input
                        type="email"
                        placeholder="Your Email"
                        name="email"
                        onChange={e => SetEmail(e.target.value)}
                        value={email || ""}
                        className="input input-bordered input-accent w-full"
                    />
                    <input
                        type="password"
                        placeholder="Password"
                        name="password"
                        onChange={e => SetPassword(e.target.value)}
                        value={password || ""}
                        className="input input-bordered input-accent w-full"
                    />
                    {logIn && (
                        <>
                            <input
                                type="password"
                                placeholder="Confirm Password"
                                name="confirmPassword"
                                onChange={e => SetConPassword(e.target.value)}
                                value={conPassword || ""}
                                onBlur={handlePassword}
                                className="input input-bordered input-accent w-full"
                            />
                            {err && (
                                <span className="label-text-alt text-lg text-red-500">
                                    {err}
                                </span>
                            )}
                        </>
                    )}
                    {logIn ? (
                        <span className="label-text-alt text-lg">
                            Already a member?{" "}
                            <button
                                onClick={() => SetLogIn(!logIn)}
                                className="link"
                            >
                                Log In
                            </button>
                        </span>
                    ) : (
                        <span className="label-text-alt text-lg">
                            New to Doctors Portal?{" "}
                            <button
                                onClick={() => SetLogIn(!logIn)}
                                className="link"
                            >
                                Create new account
                            </button>
                        </span>
                    )}
                    <input
                        type="submit"
                        value={logIn ? "Sign Up" : "Login"}
                        className="btn btn-primary w-full"
                    />
                </form>
                <div className="divider">OR</div>
                <div
                    onClick={() => signInWithGoogle()}
                    className="grid btn rounded-box place-items-center w-full lg:w-1/2 mx-auto bg-transparent"
                >
                    Continue with Google
                </div>
            </div>
        </div>
    );
};

export default LogIn;
